<?php

//Path configuration
$config['Paths']['directory'] = '.';
$config['Paths']['web'] = "http://linuxproj.ecs.soton.ac.uk/~YOURUSERNAME/forum";

//Configuration information for database
$config['Database']['db_server'] = "152.78.71.57";
$config['Database']['db_name'] = "db_YOURUSERNAME";
$config['Database']['db_user'] = "YOURUSERNAME";
$config['Database']['db_password'] = "YOURMYSQLPASSWORD";
$config['Database']['db_prefix'] = "info3005_";

//Top secret salting key
$config['Security']['salt'] = "gfh928tyh4270vbhu9";
$config['Security']['cookiesalt'] = "fh34u2fhsjuthy3i2";
$config['Security']['usersalt'] = "xkcd";

?>
